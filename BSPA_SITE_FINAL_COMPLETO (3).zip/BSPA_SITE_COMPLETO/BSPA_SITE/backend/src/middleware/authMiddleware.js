const jwt = require("jsonwebtoken");
const User = require("../models/User");

/**
 * Middleware para verificar se o usuário está autenticado
 */
const authenticateToken = async (req, res, next) => {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1]; // Bearer TOKEN

  if (!token) {
    return res.status(401).json({ message: "Token de acesso requerido" });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'fallback-secret-key');
    const user = await User.findByPk(decoded.userId);
    
    if (!user) {
      return res.status(401).json({ message: "Usuário não encontrado" });
    }

    if (!user.isActive) {
      return res.status(403).json({ message: "Conta desativada" });
    }

    req.user = user;
    next();
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({ message: "Token expirado" });
    }
    return res.status(403).json({ message: "Token inválido" });
  }
};

/**
 * Middleware para verificar se o usuário é funcionário
 */
const requireEmployee = (req, res, next) => {
  if (req.user.role !== "employee") {
    return res.status(403).json({ 
      message: "Acesso negado. Apenas funcionários podem realizar esta ação." 
    });
  }
  next();
};

/**
 * Middleware para verificar se o usuário é cliente
 */
const requireClient = (req, res, next) => {
  if (req.user.role !== "client") {
    return res.status(403).json({ 
      message: "Acesso negado. Apenas clientes podem realizar esta ação." 
    });
  }
  next();
};

/**
 * Middleware para verificar se o usuário pode acessar o recurso
 * (funcionário pode acessar tudo, cliente apenas seus próprios dados)
 */
const requireOwnershipOrEmployee = (req, res, next) => {
  const userId = parseInt(req.params.userId || req.params.id);
  
  if (req.user.role === "employee") {
    // Funcionários podem acessar qualquer recurso
    return next();
  }
  
  if (req.user.role === "client" && req.user.id === userId) {
    // Clientes podem acessar apenas seus próprios dados
    return next();
  }
  
  return res.status(403).json({ 
    message: "Acesso negado. Você só pode acessar seus próprios dados." 
  });
};

/**
 * Middleware opcional de autenticação (não falha se não houver token)
 */
const optionalAuth = async (req, res, next) => {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];

  if (!token) {
    req.user = null;
    return next();
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'fallback-secret-key');
    const user = await User.findByPk(decoded.userId);
    
    if (user && user.isActive) {
      req.user = user;
    } else {
      req.user = null;
    }
  } catch (error) {
    req.user = null;
  }
  
  next();
};

module.exports = { 
  authenticateToken, 
  requireEmployee, 
  requireClient, 
  requireOwnershipOrEmployee,
  optionalAuth 
};

