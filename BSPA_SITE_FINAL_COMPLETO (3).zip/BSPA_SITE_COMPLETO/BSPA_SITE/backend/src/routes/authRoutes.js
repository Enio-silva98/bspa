const express = require("express");
const { register, login, verifyToken, logout } = require("../controllers/authController");
const { authenticateToken } = require("../middleware/authMiddleware");

const router = express.Router();

/**
 * @route POST /api/auth/register
 * @desc Registrar um novo usuário
 * @access Public
 */
router.post("/register", register);

/**
 * @route POST /api/auth/login
 * @desc Fazer login
 * @access Public
 */
router.post("/login", login);

/**
 * @route GET /api/auth/verify
 * @desc Verificar token e retornar dados do usuário
 * @access Private
 */
router.get("/verify", authenticateToken, verifyToken);

/**
 * @route POST /api/auth/logout
 * @desc Fazer logout
 * @access Private
 */
router.post("/logout", authenticateToken, logout);

module.exports = router;

