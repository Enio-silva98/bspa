const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../middleware/authMiddleware');
const {
  upload,
  uploadDocument,
  listDocuments,
  getDocument,
  downloadDocument,
  updateDocument,
  deleteDocument,
  getDocumentStats
} = require('../controllers/documentController');

// Aplicar middleware de autenticação a todas as rotas
router.use(authenticateToken);

// Rotas para documentos
router.post('/upload', upload.single('document'), uploadDocument);
router.get('/', listDocuments);
router.get('/stats', getDocumentStats);
router.get('/:id', getDocument);
router.get('/:id/download', downloadDocument);
router.put('/:id', updateDocument);
router.delete('/:id', deleteDocument);

module.exports = router;

