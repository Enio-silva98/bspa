const express = require("express");
const {
  createReport,
  getAllReports,
  getReportById,
  updateReport,
  deleteReport,
} = require("../controllers/reportController");
const { authenticateToken, requireEmployee } = require("../middleware/authMiddleware");

const router = express.Router();

/**
 * @route GET /api/reports
 * @desc Obter todos os relatórios
 * @access Private (funcionários e clientes)
 */
router.get("/", authenticateToken, getAllReports);

/**
 * @route GET /api/reports/:id
 * @desc Obter um relatório específico
 * @access Private (funcionários e clientes)
 */
router.get("/:id", authenticateToken, getReportById);

/**
 * @route POST /api/reports
 * @desc Criar um novo relatório
 * @access Private (apenas funcionários)
 */
router.post("/", authenticateToken, requireEmployee, createReport);

/**
 * @route PUT /api/reports/:id
 * @desc Atualizar um relatório
 * @access Private (apenas funcionários)
 */
router.put("/:id", authenticateToken, requireEmployee, updateReport);

/**
 * @route DELETE /api/reports/:id
 * @desc Deletar um relatório
 * @access Private (apenas funcionários)
 */
router.delete("/:id", authenticateToken, requireEmployee, deleteReport);

module.exports = router;

