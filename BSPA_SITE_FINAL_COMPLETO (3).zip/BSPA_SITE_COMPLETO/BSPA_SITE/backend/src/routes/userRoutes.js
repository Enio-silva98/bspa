const express = require("express");
const {
  getAllUsers,
  getUserProfile,
  updateUserProfile,
  deleteUser,
} = require("../controllers/userController");
const { authenticateToken, requireEmployee } = require("../middleware/authMiddleware");

const router = express.Router();

/**
 * @route GET /api/users
 * @desc Obter todos os usuários
 * @access Private (apenas funcionários)
 */
router.get("/", authenticateToken, requireEmployee, getAllUsers);

/**
 * @route GET /api/users/profile
 * @desc Obter perfil do usuário atual
 * @access Private (funcionários e clientes)
 */
router.get("/profile", authenticateToken, getUserProfile);

/**
 * @route PUT /api/users/profile
 * @desc Atualizar perfil do usuário atual
 * @access Private (funcionários e clientes)
 */
router.put("/profile", authenticateToken, updateUserProfile);

/**
 * @route DELETE /api/users/:id
 * @desc Deletar usuário
 * @access Private (apenas funcionários)
 */
router.delete("/:id", authenticateToken, requireEmployee, deleteUser);

module.exports = router;

