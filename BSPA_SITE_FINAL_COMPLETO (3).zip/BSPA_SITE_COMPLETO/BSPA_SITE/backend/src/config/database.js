const { Sequelize } = require("sequelize");

const sequelize = new Sequelize({
  dialect: "sqlite",
  storage: "./database.sqlite", // Caminho para o arquivo do banco de dados SQLite
  logging: false, // Desabilita o log de queries SQL no console
});

module.exports = sequelize;


