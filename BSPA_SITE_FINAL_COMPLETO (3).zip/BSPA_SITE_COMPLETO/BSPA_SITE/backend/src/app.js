const express = require("express");
const cors = require("cors");
const sequelize = require("./config/database");

// Importar modelos para sincronização
require("./models/User");
require("./models/Report");
require("./models/Document");

// Importar rotas
const authRoutes = require("./routes/authRoutes");
const reportRoutes = require("./routes/reportRoutes");
const userRoutes = require("./routes/userRoutes");
const documentRoutes = require("./routes/documentRoutes");

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rotas
app.use("/api/auth", authRoutes);
app.use("/api/reports", reportRoutes);
app.use("/api/users", userRoutes);
app.use("/api/documents", documentRoutes);

// Rota de teste
app.get("/", (req, res) => {
  res.json({ message: "API BSPA VMC está funcionando!" });
});

// Sincronizar banco de dados
const initializeDatabase = async () => {
  try {
    await sequelize.authenticate();
    console.log("Conexão com o banco de dados estabelecida com sucesso.");
    
    await sequelize.sync({ force: false }); // force: true recria as tabelas
    console.log("Modelos sincronizados com o banco de dados.");
  } catch (error) {
    console.error("Erro ao conectar com o banco de dados:", error);
  }
};

initializeDatabase();

module.exports = app;

