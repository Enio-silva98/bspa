const { DataTypes } = require("sequelize");
const sequelize = require("../config/database");
const User = require("./User");

const Report = sequelize.define("Report", {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  title: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  content: {
    type: DataTypes.TEXT,
  },
  data: {
    type: DataTypes.JSON,
  },
  created_by: {
    type: DataTypes.INTEGER,
    references: {
      model: User,
      key: "id",
    },
  },
});

Report.belongsTo(User, { foreignKey: "created_by" });

module.exports = Report;

