const { DataTypes } = require("sequelize");
const sequelize = require("../config/database");
const User = require("./User");

const Statistic = sequelize.define("Statistic", {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  title: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  type: {
    type: DataTypes.ENUM("bar", "line", "pie", "indicator"),
    allowNull: false,
  },
  data: {
    type: DataTypes.JSON,
    allowNull: false,
  },
  description: {
    type: DataTypes.TEXT,
  },
  created_by: {
    type: DataTypes.INTEGER,
    references: {
      model: User,
      key: "id",
    },
  },
});

Statistic.belongsTo(User, { foreignKey: "created_by" });

module.exports = Statistic;

