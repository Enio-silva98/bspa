const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { Op } = require("sequelize");
const User = require("../models/User");

/**
 * Registrar um novo usuário
 */
const register = async (req, res) => {
  try {
    const { username, email, password, role, firstName, lastName } = req.body;

    // Validação básica
    if (!username || !password || !role) {
      return res.status(400).json({ 
        message: "Nome de usuário, senha e role são obrigatórios" 
      });
    }

    // Verificar se o usuário já existe
    const whereClause = {
      [Op.or]: [
        { username },
        ...(email ? [{ email }] : [])
      ]
    };
    
    const existingUser = await User.findOne({ where: whereClause });
    
    if (existingUser) {
      return res.status(400).json({ 
        message: "Usuário ou email já existe" 
      });
    }

    // Criptografar a senha
    const hashedPassword = await bcrypt.hash(password, 12);

    // Criar o usuário
    const user = await User.create({
      username,
      email,
      password: hashedPassword,
      role,
      firstName,
      lastName,
      isActive: true,
    });

    res.status(201).json({
      message: "Usuário criado com sucesso",
      user: { 
        id: user.id, 
        username: user.username, 
        email: user.email,
        role: user.role,
        firstName: user.firstName,
        lastName: user.lastName,
        isActive: user.isActive
      },
    });
  } catch (error) {
    console.error('Erro no registro:', error);
    res.status(500).json({ 
      message: "Erro interno do servidor", 
      error: error.message 
    });
  }
};

/**
 * Fazer login
 */
const login = async (req, res) => {
  try {
    const { username, password } = req.body;

    // Validação básica
    if (!username || !password) {
      return res.status(400).json({ 
        message: "Nome de usuário e senha são obrigatórios" 
      });
    }

    // Verificar se o usuário existe (pode ser username ou email)
    const user = await User.findOne({ 
      where: { 
        [Op.or]: [
          { username },
          { email: username }
        ]
      } 
    });
    
    if (!user) {
      return res.status(400).json({ message: "Credenciais inválidas" });
    }

    // Verificar se o usuário está ativo
    if (!user.isActive) {
      return res.status(403).json({ 
        message: "Conta desativada. Entre em contato com o administrador." 
      });
    }

    // Verificar a senha
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(400).json({ message: "Credenciais inválidas" });
    }

    // Atualizar último login
    await user.update({ lastLogin: new Date() });

    // Gerar token JWT
    const token = jwt.sign(
      { 
        userId: user.id, 
        role: user.role,
        username: user.username 
      },
      process.env.JWT_SECRET || 'fallback-secret-key',
      { expiresIn: "24h" }
    );

    res.json({
      message: "Login realizado com sucesso",
      token,
      user: { 
        id: user.id, 
        username: user.username, 
        email: user.email,
        role: user.role,
        firstName: user.firstName,
        lastName: user.lastName,
        lastLogin: user.lastLogin
      },
    });
  } catch (error) {
    console.error('Erro no login:', error);
    res.status(500).json({ 
      message: "Erro interno do servidor", 
      error: error.message 
    });
  }
};

/**
 * Verificar token e retornar dados do usuário
 */
const verifyToken = async (req, res) => {
  try {
    const user = req.user; // Vem do middleware de autenticação
    
    res.json({
      message: "Token válido",
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        firstName: user.firstName,
        lastName: user.lastName,
        lastLogin: user.lastLogin
      }
    });
  } catch (error) {
    console.error('Erro na verificação do token:', error);
    res.status(500).json({ 
      message: "Erro interno do servidor", 
      error: error.message 
    });
  }
};

/**
 * Logout (invalidar token no frontend)
 */
const logout = async (req, res) => {
  try {
    // Em uma implementação mais robusta, você poderia manter uma blacklist de tokens
    res.json({
      message: "Logout realizado com sucesso"
    });
  } catch (error) {
    console.error('Erro no logout:', error);
    res.status(500).json({ 
      message: "Erro interno do servidor", 
      error: error.message 
    });
  }
};

module.exports = { register, login, verifyToken, logout };

