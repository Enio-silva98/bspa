const multer = require('multer');
const path = require('path');
const fs = require('fs');
const Document = require('../models/Document');
const User = require('../models/User');

// Configuração do multer para upload de arquivos
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const uploadDir = path.join(__dirname, '../../uploads');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    // Gerar nome único para o arquivo
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const extension = path.extname(file.originalname);
    cb(null, file.fieldname + '-' + uniqueSuffix + extension);
  }
});

// Filtro de tipos de arquivo permitidos
const fileFilter = (req, file, cb) => {
  const allowedTypes = [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'image/jpeg',
    'image/png',
    'image/gif',
    'text/plain'
  ];

  if (allowedTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error('Tipo de arquivo não permitido'), false);
  }
};

const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB
  }
});

/**
 * Upload de documento
 */
const uploadDocument = async (req, res) => {
  try {
    const { title, description, category, isPublic, tags } = req.body;
    const file = req.file;

    if (!file) {
      return res.status(400).json({ 
        message: "Nenhum arquivo foi enviado" 
      });
    }

    if (!title) {
      return res.status(400).json({ 
        message: "Título é obrigatório" 
      });
    }

    // Criar registro do documento no banco de dados
    const document = await Document.create({
      title,
      description: description || '',
      filename: file.filename,
      originalName: file.originalname,
      mimeType: file.mimetype,
      size: file.size,
      category: category || 'outros',
      isPublic: isPublic === 'true' || isPublic === true,
      uploadedBy: req.user.id,
      tags: tags || ''
    });

    // Buscar informações do usuário que fez o upload
    const documentWithUser = await Document.findByPk(document.id, {
      include: [{
        model: User,
        as: 'uploader',
        attributes: ['id', 'username', 'firstName', 'lastName']
      }]
    });

    res.status(201).json({
      message: "Documento enviado com sucesso",
      document: documentWithUser
    });

  } catch (error) {
    console.error('Erro no upload:', error);
    
    // Remover arquivo se houve erro na criação do registro
    if (req.file && fs.existsSync(req.file.path)) {
      fs.unlinkSync(req.file.path);
    }

    res.status(500).json({ 
      message: "Erro interno do servidor",
      error: error.message 
    });
  }
};

/**
 * Listar documentos
 */
const listDocuments = async (req, res) => {
  try {
    const { category, search, page = 1, limit = 10 } = req.query;
    const userRole = req.user.role;
    
    // Construir condições da consulta
    const whereConditions = {
      isActive: true
    };

    // Clientes só veem documentos públicos
    if (userRole === 'client') {
      whereConditions.isPublic = true;
    }

    // Filtrar por categoria se especificado
    if (category && category !== 'all') {
      whereConditions.category = category;
    }

    // Busca por título ou tags
    if (search) {
      const { Op } = require('sequelize');
      whereConditions[Op.or] = [
        { title: { [Op.like]: `%${search}%` } },
        { tags: { [Op.like]: `%${search}%` } }
      ];
    }

    // Paginação
    const offset = (page - 1) * limit;

    const { count, rows: documents } = await Document.findAndCountAll({
      where: whereConditions,
      include: [{
        model: User,
        as: 'uploader',
        attributes: ['id', 'username', 'firstName', 'lastName']
      }],
      order: [['createdAt', 'DESC']],
      limit: parseInt(limit),
      offset: offset
    });

    res.json({
      documents,
      pagination: {
        total: count,
        page: parseInt(page),
        limit: parseInt(limit),
        totalPages: Math.ceil(count / limit)
      }
    });

  } catch (error) {
    console.error('Erro ao listar documentos:', error);
    res.status(500).json({ 
      message: "Erro interno do servidor",
      error: error.message 
    });
  }
};

/**
 * Obter documento por ID
 */
const getDocument = async (req, res) => {
  try {
    const { id } = req.params;
    const userRole = req.user.role;

    const whereConditions = {
      id,
      isActive: true
    };

    // Clientes só veem documentos públicos
    if (userRole === 'client') {
      whereConditions.isPublic = true;
    }

    const document = await Document.findOne({
      where: whereConditions,
      include: [{
        model: User,
        as: 'uploader',
        attributes: ['id', 'username', 'firstName', 'lastName']
      }]
    });

    if (!document) {
      return res.status(404).json({ 
        message: "Documento não encontrado" 
      });
    }

    res.json(document);

  } catch (error) {
    console.error('Erro ao buscar documento:', error);
    res.status(500).json({ 
      message: "Erro interno do servidor",
      error: error.message 
    });
  }
};

/**
 * Download de documento
 */
const downloadDocument = async (req, res) => {
  try {
    const { id } = req.params;
    const userRole = req.user.role;

    const whereConditions = {
      id,
      isActive: true
    };

    // Clientes só podem baixar documentos públicos
    if (userRole === 'client') {
      whereConditions.isPublic = true;
    }

    const document = await Document.findOne({
      where: whereConditions
    });

    if (!document) {
      return res.status(404).json({ 
        message: "Documento não encontrado" 
      });
    }

    const filePath = path.join(__dirname, '../../uploads', document.filename);

    // Verificar se o arquivo existe
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ 
        message: "Arquivo não encontrado no servidor" 
      });
    }

    // Incrementar contador de downloads
    await document.increment('downloadCount');

    // Configurar headers para download
    res.setHeader('Content-Disposition', `attachment; filename="${document.originalName}"`);
    res.setHeader('Content-Type', document.mimeType);

    // Enviar arquivo
    res.sendFile(filePath);

  } catch (error) {
    console.error('Erro no download:', error);
    res.status(500).json({ 
      message: "Erro interno do servidor",
      error: error.message 
    });
  }
};

/**
 * Atualizar documento (apenas funcionários)
 */
const updateDocument = async (req, res) => {
  try {
    if (req.user.role !== 'employee') {
      return res.status(403).json({ 
        message: "Acesso negado. Apenas funcionários podem atualizar documentos." 
      });
    }

    const { id } = req.params;
    const { title, description, category, isPublic, tags } = req.body;

    const document = await Document.findOne({
      where: { id, isActive: true }
    });

    if (!document) {
      return res.status(404).json({ 
        message: "Documento não encontrado" 
      });
    }

    // Atualizar campos
    await document.update({
      title: title || document.title,
      description: description !== undefined ? description : document.description,
      category: category || document.category,
      isPublic: isPublic !== undefined ? (isPublic === 'true' || isPublic === true) : document.isPublic,
      tags: tags !== undefined ? tags : document.tags
    });

    // Buscar documento atualizado com informações do usuário
    const updatedDocument = await Document.findByPk(document.id, {
      include: [{
        model: User,
        as: 'uploader',
        attributes: ['id', 'username', 'firstName', 'lastName']
      }]
    });

    res.json({
      message: "Documento atualizado com sucesso",
      document: updatedDocument
    });

  } catch (error) {
    console.error('Erro ao atualizar documento:', error);
    res.status(500).json({ 
      message: "Erro interno do servidor",
      error: error.message 
    });
  }
};

/**
 * Deletar documento (apenas funcionários)
 */
const deleteDocument = async (req, res) => {
  try {
    if (req.user.role !== 'employee') {
      return res.status(403).json({ 
        message: "Acesso negado. Apenas funcionários podem deletar documentos." 
      });
    }

    const { id } = req.params;

    const document = await Document.findOne({
      where: { id, isActive: true }
    });

    if (!document) {
      return res.status(404).json({ 
        message: "Documento não encontrado" 
      });
    }

    // Soft delete - marcar como inativo
    await document.update({ isActive: false });

    res.json({
      message: "Documento removido com sucesso"
    });

  } catch (error) {
    console.error('Erro ao deletar documento:', error);
    res.status(500).json({ 
      message: "Erro interno do servidor",
      error: error.message 
    });
  }
};

/**
 * Obter estatísticas de documentos
 */
const getDocumentStats = async (req, res) => {
  try {
    const userRole = req.user.role;

    const whereConditions = {
      isActive: true
    };

    // Clientes só veem estatísticas de documentos públicos
    if (userRole === 'client') {
      whereConditions.isPublic = true;
    }

    const totalDocuments = await Document.count({
      where: whereConditions
    });

    const documentsByCategory = await Document.findAll({
      where: whereConditions,
      attributes: [
        'category',
        [require('sequelize').fn('COUNT', require('sequelize').col('id')), 'count']
      ],
      group: ['category']
    });

    const recentDocuments = await Document.findAll({
      where: whereConditions,
      include: [{
        model: User,
        as: 'uploader',
        attributes: ['username', 'firstName', 'lastName']
      }],
      order: [['createdAt', 'DESC']],
      limit: 5
    });

    res.json({
      totalDocuments,
      documentsByCategory,
      recentDocuments
    });

  } catch (error) {
    console.error('Erro ao obter estatísticas:', error);
    res.status(500).json({ 
      message: "Erro interno do servidor",
      error: error.message 
    });
  }
};

module.exports = {
  upload,
  uploadDocument,
  listDocuments,
  getDocument,
  downloadDocument,
  updateDocument,
  deleteDocument,
  getDocumentStats
};

