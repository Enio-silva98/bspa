const Report = require("../models/Report");
const User = require("../models/User");

/**
 * Criar um novo relatório (apenas funcionários)
 */
const createReport = async (req, res) => {
  try {
    const { title, content, data } = req.body;
    const created_by = req.user.id;

    const report = await Report.create({
      title,
      content,
      data,
      created_by,
    });

    res.status(201).json({
      message: "Relatório criado com sucesso",
      report,
    });
  } catch (error) {
    res.status(500).json({ message: "Erro interno do servidor", error: error.message });
  }
};

/**
 * Obter todos os relatórios
 */
const getAllReports = async (req, res) => {
  try {
    const reports = await Report.findAll({
      include: [
        {
          model: User,
          attributes: ["username"],
        },
      ],
      order: [["createdAt", "DESC"]],
    });

    res.json(reports);
  } catch (error) {
    res.status(500).json({ message: "Erro interno do servidor", error: error.message });
  }
};

/**
 * Obter um relatório específico
 */
const getReportById = async (req, res) => {
  try {
    const { id } = req.params;
    const report = await Report.findByPk(id, {
      include: [
        {
          model: User,
          attributes: ["username"],
        },
      ],
    });

    if (!report) {
      return res.status(404).json({ message: "Relatório não encontrado" });
    }

    res.json(report);
  } catch (error) {
    res.status(500).json({ message: "Erro interno do servidor", error: error.message });
  }
};

/**
 * Atualizar um relatório (apenas funcionários)
 */
const updateReport = async (req, res) => {
  try {
    const { id } = req.params;
    const { title, content, data } = req.body;

    const report = await Report.findByPk(id);
    if (!report) {
      return res.status(404).json({ message: "Relatório não encontrado" });
    }

    await report.update({ title, content, data });

    res.json({
      message: "Relatório atualizado com sucesso",
      report,
    });
  } catch (error) {
    res.status(500).json({ message: "Erro interno do servidor", error: error.message });
  }
};

/**
 * Deletar um relatório (apenas funcionários)
 */
const deleteReport = async (req, res) => {
  try {
    const { id } = req.params;

    const report = await Report.findByPk(id);
    if (!report) {
      return res.status(404).json({ message: "Relatório não encontrado" });
    }

    await report.destroy();

    res.json({ message: "Relatório deletado com sucesso" });
  } catch (error) {
    res.status(500).json({ message: "Erro interno do servidor", error: error.message });
  }
};

module.exports = {
  createReport,
  getAllReports,
  getReportById,
  updateReport,
  deleteReport,
};

