const Statistic = require("../models/Statistic");
const User = require("../models/User");

/**
 * Criar uma nova estatística (apenas funcionários)
 */
const createStatistic = async (req, res) => {
  try {
    const { title, type, data, description } = req.body;
    const created_by = req.user.id;

    const statistic = await Statistic.create({
      title,
      type,
      data,
      description,
      created_by,
    });

    res.status(201).json({
      message: "Estatística criada com sucesso",
      statistic,
    });
  } catch (error) {
    res.status(500).json({ message: "Erro interno do servidor", error: error.message });
  }
};

/**
 * Obter todas as estatísticas
 */
const getAllStatistics = async (req, res) => {
  try {
    const statistics = await Statistic.findAll({
      include: [
        {
          model: User,
          attributes: ["username"],
        },
      ],
      order: [["createdAt", "DESC"]],
    });

    res.json(statistics);
  } catch (error) {
    res.status(500).json({ message: "Erro interno do servidor", error: error.message });
  }
};

/**
 * Obter uma estatística específica
 */
const getStatisticById = async (req, res) => {
  try {
    const { id } = req.params;
    const statistic = await Statistic.findByPk(id, {
      include: [
        {
          model: User,
          attributes: ["username"],
        },
      ],
    });

    if (!statistic) {
      return res.status(404).json({ message: "Estatística não encontrada" });
    }

    res.json(statistic);
  } catch (error) {
    res.status(500).json({ message: "Erro interno do servidor", error: error.message });
  }
};

/**
 * Atualizar uma estatística (apenas funcionários)
 */
const updateStatistic = async (req, res) => {
  try {
    const { id } = req.params;
    const { title, type, data, description } = req.body;

    const statistic = await Statistic.findByPk(id);
    if (!statistic) {
      return res.status(404).json({ message: "Estatística não encontrada" });
    }

    await statistic.update({ title, type, data, description });

    res.json({
      message: "Estatística atualizada com sucesso",
      statistic,
    });
  } catch (error) {
    res.status(500).json({ message: "Erro interno do servidor", error: error.message });
  }
};

/**
 * Deletar uma estatística (apenas funcionários)
 */
const deleteStatistic = async (req, res) => {
  try {
    const { id } = req.params;

    const statistic = await Statistic.findByPk(id);
    if (!statistic) {
      return res.status(404).json({ message: "Estatística não encontrada" });
    }

    await statistic.destroy();

    res.json({ message: "Estatística deletada com sucesso" });
  } catch (error) {
    res.status(500).json({ message: "Erro interno do servidor", error: error.message });
  }
};

/**
 * Obter estatísticas por tipo
 */
const getStatisticsByType = async (req, res) => {
  try {
    const { type } = req.params;
    const statistics = await Statistic.findAll({
      where: { type },
      include: [
        {
          model: User,
          attributes: ["username"],
        },
      ],
      order: [["createdAt", "DESC"]],
    });

    res.json(statistics);
  } catch (error) {
    res.status(500).json({ message: "Erro interno do servidor", error: error.message });
  }
};

module.exports = {
  createStatistic,
  getAllStatistics,
  getStatisticById,
  updateStatistic,
  deleteStatistic,
  getStatisticsByType,
};

