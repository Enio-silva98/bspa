const User = require("../models/User");

/**
 * Obter todos os usuários (apenas funcionários)
 */
const getAllUsers = async (req, res) => {
  try {
    const users = await User.findAll({
      attributes: { exclude: ["password"] }, // Não retornar senhas
      order: [["createdAt", "DESC"]],
    });

    res.json(users);
  } catch (error) {
    res.status(500).json({ message: "Erro interno do servidor", error: error.message });
  }
};

/**
 * Obter perfil do usuário atual
 */
const getUserProfile = async (req, res) => {
  try {
    const user = await User.findByPk(req.user.id, {
      attributes: { exclude: ["password"] },
    });

    if (!user) {
      return res.status(404).json({ message: "Usuário não encontrado" });
    }

    res.json(user);
  } catch (error) {
    res.status(500).json({ message: "Erro interno do servidor", error: error.message });
  }
};

/**
 * Atualizar perfil do usuário
 */
const updateUserProfile = async (req, res) => {
  try {
    const { username } = req.body;
    const userId = req.user.id;

    // Verificar se o novo username já existe (se foi alterado)
    if (username && username !== req.user.username) {
      const existingUser = await User.findOne({ where: { username } });
      if (existingUser) {
        return res.status(400).json({ message: "Nome de usuário já existe" });
      }
    }

    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({ message: "Usuário não encontrado" });
    }

    await user.update({ username: username || user.username });

    const updatedUser = await User.findByPk(userId, {
      attributes: { exclude: ["password"] },
    });

    res.json({
      message: "Perfil atualizado com sucesso",
      user: updatedUser,
    });
  } catch (error) {
    res.status(500).json({ message: "Erro interno do servidor", error: error.message });
  }
};

/**
 * Deletar usuário (apenas funcionários)
 */
const deleteUser = async (req, res) => {
  try {
    const { id } = req.params;

    // Não permitir que o usuário delete a si mesmo
    if (parseInt(id) === req.user.id) {
      return res.status(400).json({ message: "Você não pode deletar sua própria conta" });
    }

    const user = await User.findByPk(id);
    if (!user) {
      return res.status(404).json({ message: "Usuário não encontrado" });
    }

    await user.destroy();

    res.json({ message: "Usuário deletado com sucesso" });
  } catch (error) {
    res.status(500).json({ message: "Erro interno do servidor", error: error.message });
  }
};

module.exports = {
  getAllUsers,
  getUserProfile,
  updateUserProfile,
  deleteUser,
};

