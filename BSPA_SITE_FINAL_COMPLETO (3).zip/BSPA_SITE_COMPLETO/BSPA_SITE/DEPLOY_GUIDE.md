# 🚀 Guia de Deploy - BSPA Sistema

Este guia fornece instruções detalhadas para fazer deploy do sistema BSPA em diferentes plataformas de hospedagem.

---

## 📋 Preparação Geral

### 1. Variáveis de Ambiente
Antes do deploy, configure as seguintes variáveis de ambiente:

```env
# Obrigatórias
JWT_SECRET=sua_chave_secreta_jwt_muito_segura
NODE_ENV=production
PORT=5000

# Opcionais
CORS_ORIGIN=https://seu-frontend.com
MAX_FILE_SIZE=10485760
```

### 2. Estrutura de Arquivos
Certifique-se de que a estrutura está correta:
```
BSPA_SITE/
├── backend/          # API Node.js
├── frontend/         # Interface web
├── database/         # Scripts SQL
├── .env.example      # Exemplo de variáveis
└── README.md         # Documentação
```

---

## 🌐 Deploy no Render (Recomendado)

### Backend (API)

1. **Conectar Repositório**
   - Acesse [render.com](https://render.com)
   - Clique em "New +" → "Web Service"
   - Conecte seu repositório GitHub

2. **Configurar Serviço**
   ```
   Name: bspa-api
   Environment: Node
   Region: Frankfurt (EU Central)
   Branch: main
   Root Directory: backend
   ```

3. **Comandos de Build e Start**
   ```
   Build Command: npm install
   Start Command: npm start
   ```

4. **Variáveis de Ambiente**
   ```
   JWT_SECRET=sua_chave_jwt_super_secreta_aqui
   NODE_ENV=production
   PORT=10000
   ```

5. **Configurações Avançadas**
   - Auto-Deploy: Yes
   - Health Check Path: `/api/auth/verify`

### Frontend (Site)

1. **Criar Static Site**
   - Clique em "New +" → "Static Site"
   - Conecte o mesmo repositório

2. **Configurar Site**
   ```
   Name: bspa-frontend
   Branch: main
   Root Directory: frontend
   Publish Directory: .
   ```

3. **Atualizar URLs da API**
   Edite os arquivos HTML para usar a URL da API do Render:
   ```javascript
   const API_BASE_URL = 'https://bspa-api.onrender.com/api';
   ```

---

## 🚂 Deploy no Railway

### Backend

1. **Instalar CLI**
   ```bash
   npm install -g @railway/cli
   railway login
   ```

2. **Inicializar Projeto**
   ```bash
   cd backend
   railway init
   railway link [project-id]
   ```

3. **Configurar Variáveis**
   ```bash
   railway variables set JWT_SECRET=sua_chave_secreta
   railway variables set NODE_ENV=production
   ```

4. **Deploy**
   ```bash
   railway up
   ```

### Frontend

1. **Opção 1: Railway Static**
   - Crie um novo projeto no Railway
   - Conecte o repositório
   - Configure o diretório: `frontend`

2. **Opção 2: Netlify/Vercel**
   - Use Railway apenas para o backend
   - Deploy do frontend no Netlify ou Vercel

---

## 🟣 Deploy no Heroku

### Backend

1. **Instalar CLI**
   ```bash
   # Instale a CLI do Heroku
   # https://devcenter.heroku.com/articles/heroku-cli
   ```

2. **Criar App**
   ```bash
   heroku create bspa-backend
   ```

3. **Configurar Variáveis**
   ```bash
   heroku config:set JWT_SECRET=sua_chave_secreta
   heroku config:set NODE_ENV=production
   ```

4. **Preparar para Deploy**
   Crie um `Procfile` na pasta backend:
   ```
   web: node server.js
   ```

5. **Deploy**
   ```bash
   # Se o backend está na raiz
   git push heroku main

   # Se o backend está em subpasta
   git subtree push --prefix backend heroku main
   ```

### Frontend

1. **Opção 1: Heroku Static**
   - Configure buildpack para servir arquivos estáticos
   - Adicione `package.json` na pasta frontend

2. **Opção 2: Netlify**
   - Conecte o repositório no Netlify
   - Configure o diretório de publicação: `frontend`

---

## 🔧 Configurações Específicas

### Banco de Dados

#### SQLite (Desenvolvimento)
```javascript
// backend/src/config/database.js
const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: './database.sqlite'
});
```

#### PostgreSQL (Produção)
```javascript
// Para Render/Railway/Heroku
const sequelize = new Sequelize(process.env.DATABASE_URL, {
  dialect: 'postgres',
  dialectOptions: {
    ssl: {
      require: true,
      rejectUnauthorized: false
    }
  }
});
```

### CORS

```javascript
// backend/src/app.js
app.use(cors({
  origin: process.env.CORS_ORIGIN || 'http://localhost:3000',
  credentials: true
}));
```

### Upload de Arquivos

```javascript
// backend/src/controllers/documentController.js
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const uploadDir = process.env.UPLOAD_DIR || './uploads';
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  }
});
```

---

## 🔍 Verificação Pós-Deploy

### 1. Testes de API
```bash
# Teste de saúde
curl https://sua-api.com/api/auth/verify

# Teste de login
curl -X POST https://sua-api.com/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin_bspa","password":"password123"}'
```

### 2. Testes de Frontend
- [ ] Página inicial carrega corretamente
- [ ] Login funciona para funcionários e clientes
- [ ] Dashboards exibem gráficos
- [ ] Upload de documentos funciona
- [ ] Responsividade em mobile

### 3. Monitoramento
- Configure logs de erro
- Monitore performance da API
- Verifique uso de recursos

---

## 🐛 Solução de Problemas

### Erro: "Cannot connect to database"
```bash
# Verifique a variável DATABASE_URL
heroku config:get DATABASE_URL

# Teste a conexão
heroku run node -e "console.log(process.env.DATABASE_URL)"
```

### Erro: "CORS policy"
```javascript
// Adicione o domínio correto no CORS
app.use(cors({
  origin: ['https://seu-frontend.com', 'http://localhost:3000']
}));
```

### Erro: "File upload failed"
```bash
# Verifique permissões de escrita
ls -la uploads/

# Crie o diretório se não existir
mkdir -p uploads && chmod 755 uploads
```

### Erro: "JWT token invalid"
```bash
# Verifique se JWT_SECRET está definido
echo $JWT_SECRET

# Regenere tokens se necessário
heroku config:set JWT_SECRET=nova_chave_secreta
```

---

## 📊 Monitoramento e Logs

### Render
```bash
# Ver logs em tempo real
# Acesse o dashboard do Render → Logs
```

### Railway
```bash
railway logs
```

### Heroku
```bash
heroku logs --tail
heroku logs --source app
```

---

## 🔄 CI/CD (Opcional)

### GitHub Actions
Crie `.github/workflows/deploy.yml`:

```yaml
name: Deploy to Render

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    
    - name: Deploy to Render
      uses: johnbeynon/render-deploy-action@v0.0.8
      with:
        service-id: ${{ secrets.RENDER_SERVICE_ID }}
        api-key: ${{ secrets.RENDER_API_KEY }}
```

---

## 📞 Suporte

Se encontrar problemas durante o deploy:

1. **Verifique os logs** da plataforma
2. **Confirme as variáveis** de ambiente
3. **Teste localmente** antes do deploy
4. **Consulte a documentação** da plataforma

### Contato
- **Email:** geral@bspa.ao
- **Telefone:** +244 924 223 886

---

## ✅ Checklist de Deploy

### Pré-Deploy
- [ ] Código testado localmente
- [ ] Variáveis de ambiente configuradas
- [ ] URLs da API atualizadas no frontend
- [ ] Banco de dados configurado
- [ ] Arquivos de configuração criados

### Pós-Deploy
- [ ] API respondendo corretamente
- [ ] Frontend carregando
- [ ] Login funcionando
- [ ] Upload de arquivos testado
- [ ] Responsividade verificada
- [ ] Performance monitorada

---

**🎉 Parabéns! Seu sistema BSPA está no ar!**

Lembre-se de manter backups regulares e monitorar a performance do sistema.

