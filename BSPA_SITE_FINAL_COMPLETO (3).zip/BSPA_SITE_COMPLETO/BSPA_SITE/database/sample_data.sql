-- Dados de Exemplo - BSPA VMC
-- Inserir dados de teste para desenvolvimento e demonstração

-- Usuários de exemplo (senhas são hashes de 'password123')
INSERT INTO Users (username, password, role) VALUES 
('admin_bspa', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'employee'),
('funcionario1', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'employee'),
('cliente1', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'client'),
('cliente2', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'client');

-- Relatórios de exemplo
INSERT INTO Reports (title, content, data, created_by) VALUES 
(
    'Relatório Mensal de Limpeza',
    'Relatório detalhado dos serviços de limpeza realizados no mês.',
    '{"servicos_realizados": 45, "clientes_atendidos": 12, "satisfacao": 95}',
    1
),
(
    'Controlo de Pragas - Trimestre',
    'Análise trimestral dos serviços de controlo de pragas.',
    '{"intervencoes": 23, "areas_tratadas": 8, "eficacia": 98}',
    1
),
(
    'Gestão de Resíduos - Anual',
    'Relatório anual da gestão e recolha de resíduos.',
    '{"toneladas_recolhidas": 120, "reciclagem": 85, "reducao_custos": 15}',
    2
);

-- Estatísticas de exemplo
INSERT INTO Statistics (title, type, data, description, created_by) VALUES 
(
    'Serviços por Mês',
    'bar',
    '{"labels": ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun"], "datasets": [{"label": "Limpeza", "data": [12, 15, 18, 14, 20, 22]}, {"label": "Pragas", "data": [5, 7, 6, 8, 9, 10]}]}',
    'Gráfico de barras mostrando a evolução dos serviços ao longo dos meses',
    1
),
(
    'Satisfação dos Clientes',
    'pie',
    '{"labels": ["Muito Satisfeito", "Satisfeito", "Neutro", "Insatisfeito"], "datasets": [{"data": [65, 25, 8, 2], "backgroundColor": ["#4CAF50", "#2196F3", "#FF9800", "#F44336"]}]}',
    'Distribuição da satisfação dos clientes com os serviços',
    1
),
(
    'Produtividade Mensal',
    'line',
    '{"labels": ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun"], "datasets": [{"label": "Produtividade (%)", "data": [85, 88, 92, 87, 94, 96], "borderColor": "#2196F3"}]}',
    'Evolução da produtividade da equipe ao longo do tempo',
    2
),
(
    'Meta Anual',
    'indicator',
    '{"value": 78, "target": 100, "unit": "%", "color": "#4CAF50"}',
    'Progresso em relação à meta anual de crescimento',
    1
);

-- Documentos de exemplo
INSERT INTO Documents (name, path, uploaded_by) VALUES 
('Manual de Procedimentos.pdf', '/uploads/manual_procedimentos.pdf', 1),
('Certificações BSPA.pdf', '/uploads/certificacoes_bspa.pdf', 1),
('Relatório Qualidade 2024.xlsx', '/uploads/relatorio_qualidade_2024.xlsx', 2),
('Plano de Segurança.docx', '/uploads/plano_seguranca.docx', 1);

