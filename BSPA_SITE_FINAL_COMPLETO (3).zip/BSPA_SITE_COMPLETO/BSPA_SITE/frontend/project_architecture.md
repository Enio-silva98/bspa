
# Arquitetura do Projeto VMC - BSPA

## 1. Visão Geral
O projeto será desenvolvido como uma aplicação web full-stack, dividida em duas partes principais: um backend (API) e um frontend (interface do usuário). A comunicação entre eles será via requisições HTTP (RESTful API).

## 2. Tecnologias Escolhidas

### 2.1. Backend (API)
- **Linguagem:** JavaScript (Node.js)
- **Framework:** Express.js (para construção da API RESTful)
- **Banco de Dados:** SQLite (para desenvolvimento e testes, fácil de configurar e portátil). Para produção, recomenda-se PostgreSQL ou MySQL.
- **ORM:** Sequelize (para interação com o banco de dados, facilitando a modelagem e operações)
- **Autenticação:** JWT (JSON Web Tokens) para gerenciar sessões de usuários e autorização.

### 2.2. Frontend (Interface do Usuário)
- **Linguagem:** JavaScript (React)
- **Gerenciamento de Estado:** Context API ou Redux (se a complexidade aumentar)
- **Estilização:** CSS Modules ou Styled Components (para modularidade e evitar conflitos de estilo), com base na identidade visual da BSPA (tons de azul, cinza e branco).
- **Gráficos:** Chart.js ou Recharts (para visualização de dados interativos).

## 3. Estrutura do Banco de Dados (Esboço Inicial)

### Tabela: `Users`
- `id` (INTEGER, PRIMARY KEY, AUTOINCREMENT)
- `username` (TEXT, UNIQUE, NOT NULL)
- `password` (TEXT, NOT NULL) - *Armazenar hash da senha*
- `role` (TEXT, NOT NULL) - Enum: 'employee', 'client'
- `created_at` (DATETIME, DEFAULT CURRENT_TIMESTAMP)
- `updated_at` (DATETIME, DEFAULT CURRENT_TIMESTAMP)

### Tabela: `Reports`
- `id` (INTEGER, PRIMARY KEY, AUTOINCREMENT)
- `title` (TEXT, NOT NULL)
- `content` (TEXT)
- `data` (JSON) - *Para dados de gráficos e estatísticas*
- `created_by` (INTEGER, FOREIGN KEY -> Users.id)
- `created_at` (DATETIME, DEFAULT CURRENT_TIMESTAMP)
- `updated_at` (DATETIME, DEFAULT CURRENT_TIMESTAMP)

### Tabela: `Documents`
- `id` (INTEGER, PRIMARY KEY, AUTOINCREMENT)
- `name` (TEXT, NOT NULL)
- `path` (TEXT, NOT NULL) - *Caminho para o arquivo no servidor/armazenamento em nuvem*
- `uploaded_by` (INTEGER, FOREIGN KEY -> Users.id)
- `created_at` (DATETIME, DEFAULT CURRENT_TIMESTAMP)

## 4. Estrutura de Pastas do Projeto

```
bspa-vmc/
├── backend/
│   ├── src/
│   │   ├── config/
│   │   │   └── database.js
│   │   ├── controllers/
│   │   │   ├── authController.js
│   │   │   ├── userController.js
│   │   │   ├── reportController.js
│   │   │   └── documentController.js
│   │   ├── models/
│   │   │   ├── User.js
│   │   │   ├── Report.js
│   │   │   └── Document.js
│   │   ├── routes/
│   │   │   ├── authRoutes.js
│   │   │   ├── userRoutes.js
│   │   │   ├── reportRoutes.js
│   │   │   └── documentRoutes.js
│   │   ├── middleware/
│   │   │   └── authMiddleware.js
│   │   └── app.js
│   ├── .env
│   ├── package.json
│   └── server.js
├── frontend/
│   ├── public/
│   ├── src/
│   │   ├── assets/
│   │   ├── components/
│   │   ├── pages/
│   │   │   ├── LoginPage.js
│   │   │   ├── EmployeeDashboard.js
│   │   │   └── ClientDashboard.js
│   │   ├── services/
│   │   │   └── api.js
│   │   ├── App.js
│   │   └── index.js
│   ├── package.json
│   └── .env
├── .gitignore
├── README.md
└── docker-compose.yml (opcional, para ambiente de produção)
```

## 5. Próximos Passos

- **Fase 2:** Configurar o ambiente de desenvolvimento para o backend, inicializar o projeto Node.js, instalar dependências e configurar o banco de dados SQLite.

