# BSPA - Sistema de Gestão Visual
## Comércio e Prestação de Serviços

![BSPA Logo](frontend/assets/images/bspa_logo.jpeg)

---

## 📋 Sobre o Projeto

O **BSPA** é um sistema completo de gestão visual desenvolvido para a empresa BSPA - Comércio e Prestação de Serviços, uma empresa angolana especializada em diversos serviços como limpeza, eletricidade, segurança, jardinagem e ar condicionado.

### ✨ Principais Funcionalidades

- **🔐 Sistema de Login Diferenciado**
  - Funcionários: Acesso total com permissões de edição
  - Clientes: Modo visualização com acesso limitado

- **📊 Dashboard Dinâmico**
  - Gráficos interativos com Chart.js
  - Estatísticas em tempo real
  - Relatórios visuais por categoria

- **📄 Gestão de Documentos**
  - Upload com drag & drop
  - Controle de visibilidade (público/privado)
  - Sistema de categorização e tags
  - Filtros avançados de busca

- **🎨 Identidade Visual Corporativa**
  - Cores oficiais: Vermelho (#FF0000), Cinza (#808080), Preto (#000000)
  - Logotipo oficial integrado
  - 18+ imagens dos serviços da empresa
  - Design responsivo e acessível

---

## 🚀 Melhorias Implementadas

### ✅ Sistema de Autenticação Aprimorado
- **Login diferenciado** com seleção de tipo de usuário
- **Validação robusta** com feedback visual
- **JWT tokens** para segurança
- **Middleware de autorização** no backend
- **Redirecionamento automático** baseado em roles

### ✅ Dashboard Dinâmico com Gráficos
- **Dashboard do Funcionário:**
  - Gráfico de linha: Relatórios por mês
  - Gráfico de rosca: Atividades por categoria
  - Gráfico de barras: Usuários ativos
  - Gráfico radar: Performance mensal

- **Dashboard do Cliente:**
  - Gráfico de pizza: Distribuição de serviços
  - Gráfico de barras: Satisfação dos clientes
  - Modo visualização com acesso limitado

### ✅ Sistema de Gestão de Documentos
- **Upload avançado** com drag & drop
- **Tipos de arquivo suportados:** PDF, DOC, DOCX, XLS, XLSX, TXT, JPG, PNG
- **Controle de acesso:** Documentos públicos e privados
- **Sistema de categorização:** Geral, Relatórios, Contratos, Procedimentos, Financeiro
- **Busca avançada** por título, descrição e tags
- **Estatísticas** de documentos e downloads

### ✅ Melhorias Visuais e UX/UI
- **Responsividade completa** para dispositivos móveis
- **Acessibilidade aprimorada:**
  - Atributos ARIA
  - Navegação por teclado
  - Focus states visíveis
  - Feedback para leitores de tela
- **Animações suaves** e micro-interações
- **Estados de loading** e feedback visual
- **Design system** consistente

### ✅ Identidade Visual Corporativa
- **Página principal** com hero section e galeria de serviços
- **Logotipo oficial** da BSPA integrado
- **Imagem de capa** como background do hero
- **Galeria completa** com 18 imagens dos serviços:
  - Serviços de Limpeza
  - Serviços Elétricos
  - Sistemas de Segurança (CCTV)
  - Jardinagem e Paisagismo
  - Ar Condicionado e Climatização
  - Gestão de Facilities
  - E muito mais...

---

## 🛠️ Tecnologias Utilizadas

### Backend
- **Node.js** com Express.js
- **SQLite** com Sequelize ORM
- **JWT** para autenticação
- **Multer** para upload de arquivos
- **bcryptjs** para hash de senhas

### Frontend
- **HTML5, CSS3, JavaScript** (Vanilla)
- **Chart.js** para gráficos dinâmicos
- **CSS Grid e Flexbox** para layouts responsivos
- **CSS Custom Properties** para design system
- **Intersection Observer API** para animações

### Design e UX
- **Mobile-first** responsive design
- **WCAG 2.1** accessibility guidelines
- **Progressive enhancement**
- **Smooth animations** e transitions

---

## 📦 Estrutura do Projeto

```
BSPA_SITE/
├── backend/
│   ├── src/
│   │   ├── controllers/
│   │   │   ├── authController.js      # Autenticação aprimorada
│   │   │   └── documentController.js  # Gestão de documentos
│   │   ├── middleware/
│   │   │   └── authMiddleware.js      # Middleware de autorização
│   │   ├── models/
│   │   │   ├── User.js               # Modelo de usuário expandido
│   │   │   └── Document.js           # Modelo de documento
│   │   ├── routes/
│   │   │   ├── authRoutes.js         # Rotas de autenticação
│   │   │   └── documentRoutes.js     # Rotas de documentos
│   │   └── app.js                    # Configuração do Express
│   ├── uploads/                      # Diretório de uploads
│   ├── package.json
│   └── server.js                     # Servidor principal
├── frontend/
│   ├── assets/
│   │   └── images/                   # 18+ imagens da BSPA
│   ├── css/
│   │   └── bspa-styles.css          # Design system completo
│   ├── index.html                   # Página principal
│   ├── login.html                   # Login diferenciado
│   ├── dashboard-employee.html      # Dashboard funcionário
│   ├── dashboard-client.html        # Dashboard cliente
│   └── documents.html               # Gestão de documentos
├── database/
│   └── database.sqlite              # Banco de dados
├── docs/
│   └── README.md                    # Documentação original
└── README.md                        # Esta documentação
```

---

## ⚙️ Instalação e Configuração

### Pré-requisitos
- Node.js (versão 14 ou superior)
- npm ou yarn
- Git

### 1. Clone o repositório
```bash
git clone [URL_DO_REPOSITORIO]
cd BSPA_SITE
```

### 2. Instale as dependências do backend
```bash
cd backend
npm install
```

### 3. Configure as variáveis de ambiente
Crie um arquivo `.env` na pasta `backend`:
```env
PORT=5000
JWT_SECRET=sua_chave_secreta_jwt_muito_segura
NODE_ENV=development
```

### 4. Inicie o servidor backend
```bash
npm start
```

### 5. Inicie o servidor frontend
Em outro terminal:
```bash
cd frontend
# Usando Python (se disponível)
python -m http.server 3000
# OU usando Node.js
npx http-server -p 3000
```

### 6. Acesse o sistema
- **Frontend:** http://localhost:3000
- **Backend API:** http://localhost:5000

---

## 👥 Usuários de Teste

### Funcionário (Acesso Total)
- **Usuário:** `admin_bspa`
- **Senha:** `password123`
- **Permissões:** Criar, editar, excluir dados e documentos

### Cliente (Modo Visualização)
- **Usuário:** `cliente1`
- **Senha:** `password123`
- **Permissões:** Apenas visualização de dados públicos

---

## 🚀 Deploy

### Opção 1: Render (Recomendado)

#### Backend
1. Conecte seu repositório ao Render
2. Configure as variáveis de ambiente:
   - `JWT_SECRET`: Sua chave JWT
   - `NODE_ENV`: `production`
3. Configure o comando de build: `npm install`
4. Configure o comando de start: `npm start`

#### Frontend
1. Crie um novo Static Site no Render
2. Configure o diretório de publicação: `frontend`
3. Configure as variáveis de ambiente da API

### Opção 2: Railway

#### Backend
```bash
# Instale a CLI do Railway
npm install -g @railway/cli

# Faça login
railway login

# Inicie o projeto
railway init

# Configure as variáveis
railway variables set JWT_SECRET=sua_chave_secreta
railway variables set NODE_ENV=production

# Deploy
railway up
```

#### Frontend
1. Configure a URL da API no frontend
2. Use o Railway Static Sites ou configure um servidor Express para servir os arquivos estáticos

### Opção 3: Heroku

#### Backend
```bash
# Instale a CLI do Heroku
# Crie um novo app
heroku create bspa-backend

# Configure as variáveis
heroku config:set JWT_SECRET=sua_chave_secreta
heroku config:set NODE_ENV=production

# Deploy
git subtree push --prefix backend heroku main
```

#### Frontend
1. Configure a URL da API
2. Use Heroku Static ou Netlify para o frontend

---

## 📱 Responsividade

O sistema foi desenvolvido com **mobile-first design** e é totalmente responsivo:

- **Desktop:** Layout completo com sidebar e múltiplas colunas
- **Tablet:** Layout adaptado com navegação otimizada
- **Mobile:** Interface simplificada com navegação por hambúrguer
- **Breakpoints:** 480px, 768px, 1024px, 1200px

---

## ♿ Acessibilidade

Implementamos as diretrizes **WCAG 2.1 AA**:

- **Navegação por teclado** completa
- **Atributos ARIA** para leitores de tela
- **Contraste de cores** adequado
- **Focus states** visíveis
- **Feedback sonoro** para ações importantes
- **Textos alternativos** para imagens
- **Estrutura semântica** HTML5

---

## 🎨 Design System

### Cores Corporativas
```css
--bspa-red: #FF0000        /* Cor principal */
--bspa-gray: #808080       /* Cor secundária */
--bspa-black: #000000      /* Cor de texto */
--bspa-white: #FFFFFF      /* Cor de fundo */
```

### Tipografia
- **Fonte principal:** Segoe UI, Tahoma, Geneva, Verdana, sans-serif
- **Tamanhos:** 12px, 14px, 16px, 18px, 24px, 32px, 48px
- **Pesos:** 400 (normal), 500 (medium), 600 (semibold), 700 (bold)

### Espaçamentos
- **Unidade base:** 0.5rem (8px)
- **Escala:** 0.5rem, 1rem, 1.5rem, 2rem, 3rem, 4rem, 5rem

---

## 🔧 API Endpoints

### Autenticação
- `POST /api/auth/register` - Registrar usuário
- `POST /api/auth/login` - Fazer login
- `GET /api/auth/verify` - Verificar token
- `POST /api/auth/logout` - Fazer logout

### Documentos
- `GET /api/documents` - Listar documentos
- `POST /api/documents/upload` - Upload de documento
- `GET /api/documents/:id/download` - Download de documento
- `PUT /api/documents/:id` - Atualizar documento
- `DELETE /api/documents/:id` - Excluir documento
- `GET /api/documents/stats` - Estatísticas de documentos

---

## 🧪 Testes

### Funcionalidades Testadas
- ✅ Login diferenciado (Funcionário/Cliente)
- ✅ Dashboard com gráficos dinâmicos
- ✅ Upload e gestão de documentos
- ✅ Responsividade em diferentes dispositivos
- ✅ Acessibilidade com navegação por teclado
- ✅ Performance e otimização de imagens

### Navegadores Suportados
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+
- Mobile browsers (iOS Safari, Chrome Mobile)

---

## 📈 Performance

### Otimizações Implementadas
- **Lazy loading** de imagens
- **Compressão** de assets
- **Minificação** de CSS/JS
- **Cache** de recursos estáticos
- **Otimização** de imagens (WebP quando possível)
- **Code splitting** para carregamento eficiente

---

## 🔒 Segurança

### Medidas Implementadas
- **JWT tokens** com expiração
- **Hash de senhas** com bcrypt
- **Validação** de entrada de dados
- **Sanitização** de uploads
- **CORS** configurado adequadamente
- **Rate limiting** para APIs
- **Validação** de tipos de arquivo

---

## 🐛 Solução de Problemas

### Problemas Comuns

#### 1. Erro de conexão com o backend
```bash
# Verifique se o servidor está rodando
curl http://localhost:5000/api/auth/verify

# Verifique as portas
netstat -an | grep 5000
```

#### 2. Imagens não carregam
- Verifique se as imagens estão na pasta `frontend/assets/images/`
- Confirme se o servidor frontend está servindo arquivos estáticos

#### 3. Login não funciona
- Verifique se o banco de dados foi criado
- Confirme se os usuários de teste foram criados
- Verifique o JWT_SECRET nas variáveis de ambiente

---

## 📞 Suporte

Para suporte técnico ou dúvidas sobre o sistema:

- **Email:** geral@bspa.ao
- **Telefone:** +244 924 223 886
- **Localização:** Luanda, Angola

---

## 📄 Licença

Este projeto foi desenvolvido exclusivamente para a **BSPA - Comércio e Prestação de Serviços**. Todos os direitos reservados.

---

## 🙏 Agradecimentos

Agradecemos à equipe da BSPA pela confiança e por fornecer todos os recursos visuais e informações necessárias para o desenvolvimento deste sistema.

---

## 📋 Changelog

### Versão 2.0.0 (Atual)
- ✅ Sistema de login diferenciado implementado
- ✅ Dashboard dinâmico com gráficos Chart.js
- ✅ Sistema completo de gestão de documentos
- ✅ Identidade visual corporativa aplicada
- ✅ Responsividade e acessibilidade aprimoradas
- ✅ 18+ imagens dos serviços integradas
- ✅ Página principal com galeria de serviços
- ✅ Performance e segurança otimizadas

### Versão 1.0.0 (Base)
- Sistema básico de autenticação
- Dashboard simples
- Estrutura inicial do projeto

---

**© 2024 BSPA - Comércio e Prestação de Serviços. Todos os direitos reservados.**

