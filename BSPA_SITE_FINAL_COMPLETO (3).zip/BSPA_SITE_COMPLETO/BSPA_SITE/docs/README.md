# BSPA - Visual Management Center (VMC)

## 📋 Sobre o Projeto

Sistema de gerenciamento visual desenvolvido para a **BSPA – Comércio e Prestação de Serviços**, oferecendo um painel de controle completo para funcionários e uma interface de visualização para clientes.

### 🎯 Funcionalidades Principais

- **Sistema de Login Diferenciado**: Acesso específico para funcionários e clientes
- **Dashboard Interativo**: Relatórios em tempo real e estatísticas visuais
- **Gestão de Documentos**: Upload e organização de arquivos internos
- **Análises Visuais**: Gráficos de barras, linhas, pizza e indicadores de performance
- **Controle de Permissões**: Funcionários podem editar, clientes apenas visualizam
- **Design Responsivo**: Interface adaptável para desktop, tablet e mobile

---

## 🏗️ Arquitetura do Sistema

### Backend (API RESTful)
- **Tecnologia**: Node.js + Express.js
- **Banco de Dados**: SQLite (desenvolvimento) / PostgreSQL (produção)
- **ORM**: Sequelize
- **Autenticação**: JWT (JSON Web Tokens)
- **Segurança**: bcryptjs para criptografia de senhas

### Frontend (Interface do Usuário)
- **Base**: HTML5, CSS3, JavaScript (ES6+)
- **Framework**: React.js (planejado para expansão)
- **Estilização**: CSS modular com identidade visual BSPA
- **Acessibilidade**: WCAG 2.1 AA compliant

### Banco de Dados
- **Usuários**: Gestão de funcionários e clientes
- **Relatórios**: Armazenamento de dados e análises
- **Estatísticas**: Dados para gráficos e indicadores
- **Documentos**: Metadados de arquivos uploadados

---

## 📁 Estrutura do Projeto

```
BSPA_SITE/
├── backend/                 # API do servidor
│   ├── src/
│   │   ├── config/         # Configurações do banco
│   │   ├── controllers/    # Lógica de negócio
│   │   ├── models/         # Modelos do banco de dados
│   │   ├── routes/         # Rotas da API
│   │   ├── middleware/     # Middlewares de autenticação
│   │   └── app.js          # Configuração principal
│   ├── .env                # Variáveis de ambiente
│   ├── package.json        # Dependências Node.js
│   └── server.js           # Servidor principal
├── frontend/               # Interface do usuário
│   ├── index_corrigido.html # Página principal (acessível)
│   ├── assets/             # Recursos estáticos
│   └── docs/               # Documentação frontend
├── database/               # Scripts do banco de dados
│   ├── schema.sql          # Estrutura das tabelas
│   └── sample_data.sql     # Dados de exemplo
└── docs/                   # Documentação
    ├── README.md           # Este arquivo
    ├── INSTALLATION.md     # Guia de instalação
    └── API_DOCS.md         # Documentação da API
```

---

## 🚀 Instalação e Configuração

### Pré-requisitos
- Node.js (versão 16 ou superior)
- npm ou yarn
- Git

### 1. Configuração do Backend

```bash
# Navegar para a pasta do backend
cd BSPA_SITE/backend

# Instalar dependências
npm install

# Configurar variáveis de ambiente
cp .env.example .env
# Editar o arquivo .env com suas configurações

# Inicializar o banco de dados
npm run db:setup

# Iniciar o servidor de desenvolvimento
npm run dev
```

### 2. Configuração do Frontend

```bash
# Navegar para a pasta do frontend
cd BSPA_SITE/frontend

# Para desenvolvimento local, usar um servidor HTTP simples
python3 -m http.server 3000
# ou
npx serve .
```

### 3. Configuração do Banco de Dados

```bash
# Executar scripts SQL (se necessário)
sqlite3 database.sqlite < ../database/schema.sql
sqlite3 database.sqlite < ../database/sample_data.sql
```

---

## 🔧 Scripts Disponíveis

### Backend
- `npm start` - Inicia o servidor de produção
- `npm run dev` - Inicia o servidor de desenvolvimento com nodemon
- `npm run db:setup` - Configura o banco de dados
- `npm test` - Executa os testes

### Frontend
- Servir arquivos estáticos com qualquer servidor HTTP
- Planejado: Scripts React para build e desenvolvimento

---

## 🌐 Endpoints da API

### Autenticação
- `POST /api/auth/register` - Registrar usuário
- `POST /api/auth/login` - Fazer login

### Usuários
- `GET /api/users` - Listar usuários (funcionários)
- `GET /api/users/profile` - Perfil do usuário atual
- `PUT /api/users/profile` - Atualizar perfil
- `DELETE /api/users/:id` - Deletar usuário (funcionários)

### Relatórios
- `GET /api/reports` - Listar relatórios
- `GET /api/reports/:id` - Obter relatório específico
- `POST /api/reports` - Criar relatório (funcionários)
- `PUT /api/reports/:id` - Atualizar relatório (funcionários)
- `DELETE /api/reports/:id` - Deletar relatório (funcionários)

### Estatísticas
- `GET /api/statistics` - Listar estatísticas
- `GET /api/statistics/:id` - Obter estatística específica
- `GET /api/statistics/type/:type` - Estatísticas por tipo
- `POST /api/statistics` - Criar estatística (funcionários)
- `PUT /api/statistics/:id` - Atualizar estatística (funcionários)
- `DELETE /api/statistics/:id` - Deletar estatística (funcionários)

---

## 👥 Usuários de Teste

### Funcionário
- **Usuário**: `admin_bspa`
- **Senha**: `password123`
- **Permissões**: Criar, editar, deletar dados

### Cliente
- **Usuário**: `cliente1`
- **Senha**: `password123`
- **Permissões**: Apenas visualização

---

## 🎨 Identidade Visual

### Paleta de Cores
- **Primária**: #b50000 (Vermelho BSPA)
- **Secundária**: #2196F3 (Azul)
- **Neutras**: #f5f5f5, #dcdcdc, #333333
- **Sucesso**: #4CAF50
- **Alerta**: #FF9800
- **Erro**: #F44336

### Tipografia
- **Fonte Principal**: Arial, sans-serif
- **Tamanhos**: 72px (títulos), 36px (subtítulos), 24px (corpo)

---

## 🔒 Segurança

- Senhas criptografadas com bcryptjs
- Autenticação via JWT com expiração de 24h
- Middleware de autorização por roles
- Validação de entrada em todas as rotas
- CORS configurado para desenvolvimento

---

## 📱 Responsividade

- **Desktop**: Layout completo com sidebar
- **Tablet**: Layout adaptado (768px+)
- **Mobile**: Layout compacto (600px-)
- **Acessibilidade**: WCAG 2.1 AA compliant

---

## 🚀 Deploy

### Opções de Hospedagem
1. **Render** (recomendado)
2. **Railway**
3. **Heroku**
4. **Vercel** (frontend)
5. **Netlify** (frontend)

### Variáveis de Ambiente para Produção
```
NODE_ENV=production
JWT_SECRET=sua_chave_secreta_super_segura
DATABASE_URL=sua_url_do_banco_postgresql
PORT=5000
```

---

## 📈 Próximos Passos

### Fase Atual: Backend API Completo ✅
- [x] Sistema de autenticação
- [x] Gestão de usuários
- [x] CRUD de relatórios
- [x] CRUD de estatísticas
- [x] Middleware de segurança

### Próximas Fases:
1. **Frontend React** - Interface moderna e interativa
2. **Dashboard Dinâmico** - Gráficos em tempo real
3. **Gestão de Documentos** - Upload e download
4. **Notificações** - Sistema de alertas
5. **Relatórios Avançados** - Exportação PDF/Excel

---

## 🤝 Contribuição

Para contribuir com o projeto:
1. Faça um fork do repositório
2. Crie uma branch para sua feature
3. Commit suas mudanças
4. Faça um push para a branch
5. Abra um Pull Request

---

## 📞 Suporte

Para dúvidas ou suporte técnico:
- **Email**: suporte@bspa.pt
- **Telefone**: +351 XXX XXX XXX
- **Documentação**: Consulte os arquivos em `/docs`

---

## 📄 Licença

Este projeto é propriedade da **BSPA – Comércio e Prestação de Serviços, Lda.**
Todos os direitos reservados.

---

**Desenvolvido com ❤️ para a BSPA**

