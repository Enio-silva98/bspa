# 🚀 Guia de Instalação - BSPA VMC

## 📋 Pré-requisitos

Antes de iniciar a instalação, certifique-se de ter os seguintes softwares instalados:

### Obrigatórios
- **Node.js** (versão 16.0.0 ou superior)
  - Download: https://nodejs.org/
  - Verificar: `node --version`
- **npm** (geralmente vem com Node.js)
  - Verificar: `npm --version`
- **Git** (para controle de versão)
  - Download: https://git-scm.com/
  - Verificar: `git --version`

### Opcionais (para produção)
- **PostgreSQL** (para banco de dados em produção)
- **PM2** (para gerenciamento de processos)
- **Nginx** (para proxy reverso)

---

## 💻 Instalação Local (Desenvolvimento)

### 1. Preparação do Ambiente

```bash
# Criar diretório do projeto
mkdir bspa-vmc-project
cd bspa-vmc-project

# Extrair os arquivos do projeto
unzip BSPA_SITE.zip
cd BSPA_SITE
```

### 2. Configuração do Backend

```bash
# Navegar para o backend
cd backend

# Instalar dependências
npm install

# Criar arquivo de ambiente (copiar do exemplo)
cp .env.example .env

# Editar variáveis de ambiente
nano .env
```

**Configuração do .env:**
```env
# Ambiente
NODE_ENV=development

# Servidor
PORT=5000

# Segurança
JWT_SECRET=sua_chave_secreta_muito_segura_aqui

# Banco de Dados (SQLite para desenvolvimento)
DB_DIALECT=sqlite
DB_STORAGE=./database.sqlite

# CORS (para desenvolvimento local)
CORS_ORIGIN=http://localhost:3000
```

### 3. Inicialização do Banco de Dados

```bash
# O banco será criado automaticamente na primeira execução
# Para popular com dados de exemplo:
npm run seed

# Ou manualmente:
sqlite3 database.sqlite < ../database/schema.sql
sqlite3 database.sqlite < ../database/sample_data.sql
```

### 4. Iniciar o Backend

```bash
# Desenvolvimento (com auto-reload)
npm run dev

# Ou produção
npm start
```

O servidor estará disponível em: `http://localhost:5000`

### 5. Configuração do Frontend

```bash
# Em outro terminal, navegar para o frontend
cd ../frontend

# Instalar servidor HTTP simples (se não tiver)
npm install -g http-server

# Iniciar servidor frontend
http-server -p 3000 -c-1

# Ou usar Python
python3 -m http.server 3000
```

O frontend estará disponível em: `http://localhost:3000`

---

## 🌐 Deploy em Produção

### Opção 1: Render (Recomendado)

#### Backend no Render

1. **Criar conta no Render**: https://render.com/
2. **Conectar repositório Git**
3. **Configurar Web Service**:
   - **Build Command**: `cd backend && npm install`
   - **Start Command**: `cd backend && npm start`
   - **Environment**: Node.js

4. **Variáveis de Ambiente**:
```env
NODE_ENV=production
JWT_SECRET=sua_chave_super_secreta_producao
DATABASE_URL=postgresql://user:pass@host:port/dbname
PORT=10000
```

5. **Banco de Dados PostgreSQL**:
   - Criar PostgreSQL database no Render
   - Copiar DATABASE_URL para as variáveis de ambiente

#### Frontend no Render (Static Site)

1. **Criar Static Site**
2. **Build Command**: `echo "Static files ready"`
3. **Publish Directory**: `frontend`

### Opção 2: Railway

```bash
# Instalar Railway CLI
npm install -g @railway/cli

# Login
railway login

# Deploy backend
cd backend
railway init
railway up

# Deploy frontend
cd ../frontend
railway init
railway up
```

### Opção 3: Heroku

```bash
# Instalar Heroku CLI
# https://devcenter.heroku.com/articles/heroku-cli

# Login
heroku login

# Criar app para backend
heroku create bspa-vmc-backend

# Configurar variáveis
heroku config:set NODE_ENV=production
heroku config:set JWT_SECRET=sua_chave_secreta

# Deploy
git push heroku main
```

---

## 🔧 Configurações Avançadas

### Banco de Dados PostgreSQL

```bash
# Instalar dependência PostgreSQL
cd backend
npm install pg pg-hstore

# Configurar .env para PostgreSQL
DATABASE_URL=postgresql://username:password@localhost:5432/bspa_vmc
DB_DIALECT=postgres
```

### Proxy Reverso com Nginx

```nginx
# /etc/nginx/sites-available/bspa-vmc
server {
    listen 80;
    server_name seu-dominio.com;

    # Frontend
    location / {
        root /var/www/bspa-vmc/frontend;
        try_files $uri $uri/ /index.html;
    }

    # API Backend
    location /api/ {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

### Gerenciamento com PM2

```bash
# Instalar PM2
npm install -g pm2

# Criar arquivo de configuração
# ecosystem.config.js
module.exports = {
  apps: [{
    name: 'bspa-vmc-backend',
    script: './backend/server.js',
    env: {
      NODE_ENV: 'production',
      PORT: 5000
    }
  }]
};

# Iniciar com PM2
pm2 start ecosystem.config.js

# Salvar configuração
pm2 save
pm2 startup
```

---

## 🔍 Verificação da Instalação

### Testes de Conectividade

```bash
# Testar backend
curl http://localhost:5000/
# Resposta esperada: {"message": "API BSPA VMC está funcionando!"}

# Testar autenticação
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "admin_bspa", "password": "password123"}'
```

### Verificar Logs

```bash
# Logs do backend (desenvolvimento)
npm run dev

# Logs do PM2 (produção)
pm2 logs bspa-vmc-backend

# Logs do sistema
tail -f /var/log/nginx/access.log
```

---

## 🐛 Solução de Problemas

### Problemas Comuns

#### 1. Erro de Porta em Uso
```bash
# Encontrar processo usando a porta
lsof -i :5000

# Matar processo
kill -9 PID
```

#### 2. Erro de Permissões
```bash
# Dar permissões corretas
chmod +x backend/server.js
chown -R $USER:$USER BSPA_SITE/
```

#### 3. Erro de Dependências
```bash
# Limpar cache npm
npm cache clean --force

# Reinstalar dependências
rm -rf node_modules package-lock.json
npm install
```

#### 4. Erro de Banco de Dados
```bash
# Recriar banco SQLite
rm backend/database.sqlite
cd backend && npm start
```

### Logs de Debug

```bash
# Ativar logs detalhados
export DEBUG=*
npm run dev

# Ou no .env
DEBUG=sequelize:*
```

---

## 📊 Monitoramento

### Métricas Importantes
- **CPU Usage**: < 70%
- **Memory Usage**: < 80%
- **Response Time**: < 500ms
- **Uptime**: > 99.9%

### Ferramentas de Monitoramento
- **PM2 Monitor**: `pm2 monit`
- **Render Metrics**: Dashboard do Render
- **New Relic**: Para monitoramento avançado

---

## 🔄 Atualizações

### Atualizar Dependências
```bash
# Verificar dependências desatualizadas
npm outdated

# Atualizar dependências
npm update

# Atualizar dependências de segurança
npm audit fix
```

### Deploy de Atualizações
```bash
# Git workflow
git add .
git commit -m "feat: nova funcionalidade"
git push origin main

# Deploy automático (se configurado)
# Ou manual no Render/Railway
```

---

## 📞 Suporte Técnico

### Antes de Solicitar Suporte
1. Verificar logs de erro
2. Consultar esta documentação
3. Verificar issues conhecidos
4. Testar em ambiente limpo

### Informações para Suporte
- Versão do Node.js: `node --version`
- Versão do npm: `npm --version`
- Sistema operacional
- Logs de erro completos
- Passos para reproduzir o problema

---

**✅ Instalação Concluída com Sucesso!**

Acesse o sistema em: `http://localhost:3000`
API disponível em: `http://localhost:5000`

