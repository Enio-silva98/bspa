# 📡 Documentação da API - BSPA VMC

## 🌐 Informações Gerais

- **Base URL**: `http://localhost:5000/api` (desenvolvimento)
- **Produção**: `https://sua-api.render.com/api`
- **Formato**: JSON
- **Autenticação**: JWT Bearer Token
- **Versão**: 1.0.0

---

## 🔐 Autenticação

### Obter Token de Acesso

**POST** `/auth/login`

```json
{
  "username": "admin_bspa",
  "password": "password123"
}
```

**Resposta de Sucesso (200):**
```json
{
  "message": "Login realizado com sucesso",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "username": "admin_bspa",
    "role": "employee"
  }
}
```

### Usar Token nas Requisições

```bash
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

---

## 👥 Endpoints de Autenticação

### 1. Registrar Usuário

**POST** `/auth/register`

```json
{
  "username": "novo_usuario",
  "password": "senha_segura",
  "role": "client"
}
```

**Resposta (201):**
```json
{
  "message": "Usuário criado com sucesso",
  "user": {
    "id": 5,
    "username": "novo_usuario",
    "role": "client"
  }
}
```

### 2. Login

**POST** `/auth/login`

```json
{
  "username": "admin_bspa",
  "password": "password123"
}
```

**Resposta (200):**
```json
{
  "message": "Login realizado com sucesso",
  "token": "jwt_token_aqui",
  "user": {
    "id": 1,
    "username": "admin_bspa",
    "role": "employee"
  }
}
```

---

## 👤 Endpoints de Usuários

### 1. Listar Todos os Usuários
**GET** `/users`
- **Acesso**: Apenas funcionários
- **Headers**: `Authorization: Bearer {token}`

**Resposta (200):**
```json
[
  {
    "id": 1,
    "username": "admin_bspa",
    "role": "employee",
    "createdAt": "2025-01-01T00:00:00.000Z",
    "updatedAt": "2025-01-01T00:00:00.000Z"
  }
]
```

### 2. Obter Perfil Atual
**GET** `/users/profile`
- **Acesso**: Funcionários e clientes
- **Headers**: `Authorization: Bearer {token}`

**Resposta (200):**
```json
{
  "id": 1,
  "username": "admin_bspa",
  "role": "employee",
  "createdAt": "2025-01-01T00:00:00.000Z",
  "updatedAt": "2025-01-01T00:00:00.000Z"
}
```

### 3. Atualizar Perfil
**PUT** `/users/profile`
- **Acesso**: Funcionários e clientes
- **Headers**: `Authorization: Bearer {token}`

```json
{
  "username": "novo_nome_usuario"
}
```

**Resposta (200):**
```json
{
  "message": "Perfil atualizado com sucesso",
  "user": {
    "id": 1,
    "username": "novo_nome_usuario",
    "role": "employee"
  }
}
```

### 4. Deletar Usuário
**DELETE** `/users/{id}`
- **Acesso**: Apenas funcionários
- **Headers**: `Authorization: Bearer {token}`

**Resposta (200):**
```json
{
  "message": "Usuário deletado com sucesso"
}
```

---

## 📊 Endpoints de Relatórios

### 1. Listar Relatórios
**GET** `/reports`
- **Acesso**: Funcionários e clientes
- **Headers**: `Authorization: Bearer {token}`

**Resposta (200):**
```json
[
  {
    "id": 1,
    "title": "Relatório Mensal de Limpeza",
    "content": "Relatório detalhado dos serviços...",
    "data": {
      "servicos_realizados": 45,
      "clientes_atendidos": 12,
      "satisfacao": 95
    },
    "created_by": 1,
    "createdAt": "2025-01-01T00:00:00.000Z",
    "User": {
      "username": "admin_bspa"
    }
  }
]
```

### 2. Obter Relatório Específico
**GET** `/reports/{id}`
- **Acesso**: Funcionários e clientes
- **Headers**: `Authorization: Bearer {token}`

**Resposta (200):**
```json
{
  "id": 1,
  "title": "Relatório Mensal de Limpeza",
  "content": "Relatório detalhado dos serviços de limpeza realizados no mês.",
  "data": {
    "servicos_realizados": 45,
    "clientes_atendidos": 12,
    "satisfacao": 95
  },
  "created_by": 1,
  "createdAt": "2025-01-01T00:00:00.000Z",
  "User": {
    "username": "admin_bspa"
  }
}
```

### 3. Criar Relatório
**POST** `/reports`
- **Acesso**: Apenas funcionários
- **Headers**: `Authorization: Bearer {token}`

```json
{
  "title": "Novo Relatório",
  "content": "Conteúdo do relatório...",
  "data": {
    "metricas": "valores",
    "indicadores": "dados"
  }
}
```

**Resposta (201):**
```json
{
  "message": "Relatório criado com sucesso",
  "report": {
    "id": 4,
    "title": "Novo Relatório",
    "content": "Conteúdo do relatório...",
    "data": {
      "metricas": "valores",
      "indicadores": "dados"
    },
    "created_by": 1
  }
}
```

### 4. Atualizar Relatório
**PUT** `/reports/{id}`
- **Acesso**: Apenas funcionários
- **Headers**: `Authorization: Bearer {token}`

```json
{
  "title": "Relatório Atualizado",
  "content": "Novo conteúdo...",
  "data": {
    "novos_dados": "valores_atualizados"
  }
}
```

**Resposta (200):**
```json
{
  "message": "Relatório atualizado com sucesso",
  "report": {
    "id": 1,
    "title": "Relatório Atualizado",
    "content": "Novo conteúdo...",
    "data": {
      "novos_dados": "valores_atualizados"
    }
  }
}
```

### 5. Deletar Relatório
**DELETE** `/reports/{id}`
- **Acesso**: Apenas funcionários
- **Headers**: `Authorization: Bearer {token}`

**Resposta (200):**
```json
{
  "message": "Relatório deletado com sucesso"
}
```

---

## 📈 Endpoints de Estatísticas

### 1. Listar Estatísticas
**GET** `/statistics`
- **Acesso**: Funcionários e clientes
- **Headers**: `Authorization: Bearer {token}`

**Resposta (200):**
```json
[
  {
    "id": 1,
    "title": "Serviços por Mês",
    "type": "bar",
    "data": {
      "labels": ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun"],
      "datasets": [
        {
          "label": "Limpeza",
          "data": [12, 15, 18, 14, 20, 22]
        }
      ]
    },
    "description": "Gráfico de barras mostrando a evolução dos serviços",
    "created_by": 1,
    "User": {
      "username": "admin_bspa"
    }
  }
]
```

### 2. Obter Estatística por ID
**GET** `/statistics/{id}`
- **Acesso**: Funcionários e clientes
- **Headers**: `Authorization: Bearer {token}`

### 3. Obter Estatísticas por Tipo
**GET** `/statistics/type/{type}`
- **Acesso**: Funcionários e clientes
- **Headers**: `Authorization: Bearer {token}`
- **Tipos válidos**: `bar`, `line`, `pie`, `indicator`

**Exemplo**: `/statistics/type/bar`

### 4. Criar Estatística
**POST** `/statistics`
- **Acesso**: Apenas funcionários
- **Headers**: `Authorization: Bearer {token}`

```json
{
  "title": "Nova Estatística",
  "type": "pie",
  "data": {
    "labels": ["Categoria A", "Categoria B"],
    "datasets": [
      {
        "data": [60, 40],
        "backgroundColor": ["#4CAF50", "#2196F3"]
      }
    ]
  },
  "description": "Descrição da estatística"
}
```

### 5. Atualizar Estatística
**PUT** `/statistics/{id}`
- **Acesso**: Apenas funcionários
- **Headers**: `Authorization: Bearer {token}`

### 6. Deletar Estatística
**DELETE** `/statistics/{id}`
- **Acesso**: Apenas funcionários
- **Headers**: `Authorization: Bearer {token}`

---

## 📄 Endpoints de Documentos

### 1. Listar Documentos
**GET** `/documents`
- **Acesso**: Funcionários e clientes
- **Headers**: `Authorization: Bearer {token}`

**Resposta (200):**
```json
[
  {
    "id": 1,
    "name": "Manual de Procedimentos.pdf",
    "path": "/uploads/manual_procedimentos.pdf",
    "uploaded_by": 1,
    "createdAt": "2025-01-01T00:00:00.000Z",
    "User": {
      "username": "admin_bspa"
    }
  }
]
```

### 2. Upload de Documento
**POST** `/documents/upload`
- **Acesso**: Apenas funcionários
- **Headers**: `Authorization: Bearer {token}`
- **Content-Type**: `multipart/form-data`

```bash
curl -X POST \
  -H "Authorization: Bearer {token}" \
  -F "document=@arquivo.pdf" \
  -F "name=Nome do Documento" \
  http://localhost:5000/api/documents/upload
```

### 3. Download de Documento
**GET** `/documents/{id}/download`
- **Acesso**: Funcionários e clientes
- **Headers**: `Authorization: Bearer {token}`

### 4. Deletar Documento
**DELETE** `/documents/{id}`
- **Acesso**: Apenas funcionários
- **Headers**: `Authorization: Bearer {token}`

---

## ❌ Códigos de Erro

### Códigos HTTP Comuns

| Código | Significado | Descrição |
|--------|-------------|-----------|
| 200 | OK | Requisição bem-sucedida |
| 201 | Created | Recurso criado com sucesso |
| 400 | Bad Request | Dados inválidos na requisição |
| 401 | Unauthorized | Token ausente ou inválido |
| 403 | Forbidden | Sem permissão para acessar |
| 404 | Not Found | Recurso não encontrado |
| 500 | Internal Server Error | Erro interno do servidor |

### Exemplos de Respostas de Erro

**401 - Token Ausente:**
```json
{
  "message": "Token de acesso requerido"
}
```

**403 - Sem Permissão:**
```json
{
  "message": "Acesso negado. Apenas funcionários podem realizar esta ação."
}
```

**404 - Não Encontrado:**
```json
{
  "message": "Relatório não encontrado"
}
```

**400 - Dados Inválidos:**
```json
{
  "message": "Usuário já existe"
}
```

**500 - Erro Interno:**
```json
{
  "message": "Erro interno do servidor",
  "error": "Detalhes do erro..."
}
```

---

## 🔧 Exemplos de Uso

### JavaScript (Fetch API)

```javascript
// Login
const login = async () => {
  const response = await fetch('http://localhost:5000/api/auth/login', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      username: 'admin_bspa',
      password: 'password123'
    })
  });
  
  const data = await response.json();
  localStorage.setItem('token', data.token);
};

// Obter relatórios
const getReports = async () => {
  const token = localStorage.getItem('token');
  const response = await fetch('http://localhost:5000/api/reports', {
    headers: {
      'Authorization': `Bearer ${token}`
    }
  });
  
  const reports = await response.json();
  return reports;
};
```

### cURL

```bash
# Login
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "admin_bspa", "password": "password123"}'

# Obter relatórios
curl -X GET http://localhost:5000/api/reports \
  -H "Authorization: Bearer SEU_TOKEN_AQUI"

# Criar relatório
curl -X POST http://localhost:5000/api/reports \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer SEU_TOKEN_AQUI" \
  -d '{
    "title": "Novo Relatório",
    "content": "Conteúdo do relatório",
    "data": {"metric": "value"}
  }'
```

---

## 🔄 Rate Limiting

- **Limite**: 100 requisições por minuto por IP
- **Headers de Resposta**:
  - `X-RateLimit-Limit`: Limite total
  - `X-RateLimit-Remaining`: Requisições restantes
  - `X-RateLimit-Reset`: Timestamp do reset

---

## 📝 Changelog

### v1.0.0 (2025-01-01)
- ✅ Sistema de autenticação JWT
- ✅ CRUD completo de usuários
- ✅ CRUD completo de relatórios
- ✅ CRUD completo de estatísticas
- ✅ Sistema de permissões por role
- ✅ Documentação completa da API

### Próximas Versões
- 🔄 Upload de documentos
- 🔄 Notificações em tempo real
- 🔄 Exportação de relatórios
- 🔄 Filtros avançados
- 🔄 Paginação

---

**📡 API BSPA VMC - Documentação Completa**

