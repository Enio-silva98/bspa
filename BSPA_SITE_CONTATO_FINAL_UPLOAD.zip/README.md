# Site BSPA - Comércio e Prestação de Serviços

## Descrição
Site institucional da BSPA (Comércio e Prestação de Serviços), uma empresa angolana especializada em soluções de alta qualidade para empresas e instituições.

## Funcionalidades
- **Página Principal**: Apresentação da empresa, serviços e informações de contato
- **Sistema de Agendamento**: Calendário interativo para agendamento de serviços
- **Formulário de Contato**: Captura de leads e solicitações de orçamento
- **Design Responsivo**: Compatível com desktop e dispositivos móveis
- **Redirecionamento de Serviços**: Cards de serviços redirecionam para página de agendamento

## Estrutura do Projeto
```
bspa_site/
├── index.html              # Página principal
├── servicos.html           # Página de agendamento
├── formulario.html         # Página de formulário de contato
├── calendario.html         # Página do calendário
├── css/
│   └── bspa-styles.css    # Estilos personalizados
└── public/
    └── assets/
        ├── logo/          # Logotipo da empresa
        ├── images/        # Imagens principais do site
        └── services/      # Imagens dos serviços
```

## Imagens Utilizadas

### Imagem da Capa
- **Arquivo**: `public/assets/images/capa_site.png`
- **Descrição**: Imagem de trabalhadores da BSPA em destaque no topo do site
- **Uso**: Background da seção hero com overlay vermelho/cinza

### Imagem da Seção "Nossa Missão"
- **Arquivo**: `public/assets/images/nossa_missao.png`
- **Descrição**: Logo da BSPA com mapa de Angola
- **Uso**: Seção "Sobre a BSPA" ao lado do texto da missão

### Imagem da Fiscalização de Obras
- **Arquivo**: `public/assets/images/fiscalizacao_obras.png`
- **Descrição**: Mascote representativo da BSPA
- **Uso**: Card do serviço de Fiscalização de Obras

## Como Alterar as Imagens

### 1. Substituir Imagens Existentes
Para alterar qualquer imagem do site:

1. **Prepare a nova imagem**:
   - Formatos aceitos: PNG, JPG, WEBP
   - Resolução recomendada para capa: 1920x1080px ou superior
   - Resolução recomendada para outras imagens: 800x600px

2. **Substitua o arquivo**:
   - Navegue até a pasta correspondente em `public/assets/`
   - Substitua o arquivo mantendo o mesmo nome
   - Ou altere o nome no código HTML correspondente

3. **Localizações no código**:
   - **Capa do site**: Linha ~100 em `index.html` - `background: url("public/assets/images/capa_site.png")`
   - **Nossa Missão**: Linha ~500 em `index.html` - `<img src="public/assets/images/nossa_missao.png">`
   - **Fiscalização**: Linha ~600 em `index.html` - `<img src="public/assets/images/fiscalizacao_obras.png">`

### 2. Adicionar Novas Imagens
1. Coloque a nova imagem na pasta `public/assets/images/`
2. Atualize o caminho no arquivo HTML correspondente
3. Teste o site localmente antes de fazer deploy

### 3. Otimização de Imagens
- Use ferramentas de compressão para reduzir o tamanho dos arquivos
- Considere usar formatos modernos como WEBP para melhor performance
- Mantenha backups das imagens originais

## Informações de Contato Atualizadas

### Email
- **Atual**: geral@bspa.ao
- **Localização no código**: 
  - Rodapé: Linha ~776 em `index.html`
  - Seção de contato: Verificar se há outras ocorrências

### Localização
- **Atual**: Talatona, Condomínio Espaços Avenida, Edifício Beta, Escritório LP1-11
- **Localização no código**: 
  - Rodapé: Linha ~777 em `index.html`
  - Seção de contato: Verificar se há outras ocorrências

### Como Atualizar Informações de Contato
1. Abra o arquivo `index.html`
2. Procure pelas seções que contêm as informações de contato
3. Atualize os dados conforme necessário
4. Teste o site localmente
5. Faça o deploy das alterações

## Cores Oficiais da BSPA
- **Vermelho Principal**: #FF0000
- **Cinza Secundário**: #808080
- **Preto**: #000000
- **Cinza Claro**: #f5f5f5
- **Branco**: #ffffff

## Tecnologias Utilizadas
- HTML5
- CSS3 (com variáveis CSS)
- JavaScript (para interatividade)
- Design responsivo com media queries
- Fontes Google (Montserrat)

## Deploy
O site está configurado para deploy automático. Após fazer alterações:
1. Teste localmente usando um servidor HTTP
2. Faça o deploy usando as ferramentas de deployment disponíveis
3. Verifique se todas as funcionalidades estão operando corretamente

## Suporte
Para dúvidas sobre alterações no site ou problemas técnicos, consulte a documentação ou entre em contato com o desenvolvedor responsável.

---

**Última atualização**: Julho 2025
**Versão**: 3.0 - Informações de contato atualizadas

